create function get_fields_from_json()
    returns TABLE(id integer, groupname character varying, auditorium character varying, teacher character varying, weektype character varying, discipline character varying, lessonnumber character varying, dayofweek character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT g.id::int                                                     as id,
                        g.group_name::varchar                                         as groupName,
                        (jsonb_array_elements(g.timetable) ->> 'auditorium')::varchar  AS auditorium,
                        (jsonb_array_elements(g.timetable) ->> 'teacher')::varchar     AS teacher,
                        (jsonb_array_elements(g.timetable) ->> 'week_type')::varchar   AS weekType,
                        (jsonb_array_elements(g.timetable) ->> 'discipline')::varchar  AS discipline,
                        (jsonb_array_elements(g.timetable) ->> 'number')::varchar      AS lessonNumber,
                        (jsonb_array_elements(g.timetable) ->> 'day_of_week')::varchar AS dayOfWeek
                 FROM groups g;
END;
$$;

alter function get_fields_from_json() owner to fbjfnxqsalkevb;

